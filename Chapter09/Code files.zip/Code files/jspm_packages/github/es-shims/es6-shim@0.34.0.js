define(["github:es-shims/es6-shim@0.34.0/es6-shim"], function(main) {
  return main;
});