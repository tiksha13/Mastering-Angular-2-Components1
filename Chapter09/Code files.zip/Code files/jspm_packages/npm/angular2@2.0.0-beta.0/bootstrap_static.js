/* */ 
'use strict';
var browser_static_1 = require('./platform/browser_static');
exports.bootstrapStatic = browser_static_1.bootstrapStatic;
var angular_entrypoint_1 = require('./src/core/angular_entrypoint');
exports.AngularEntrypoint = angular_entrypoint_1.AngularEntrypoint;
