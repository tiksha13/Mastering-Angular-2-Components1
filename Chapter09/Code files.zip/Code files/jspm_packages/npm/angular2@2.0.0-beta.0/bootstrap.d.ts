/**
 * See {@link bootstrap} for more information.
 * @deprecated
 */
export { bootstrap } from 'angular2/platform/browser';
export { AngularEntrypoint } from 'angular2/src/core/angular_entrypoint';
