define(["github:pouchdb/pouchdb@5.1.0/dist/pouchdb"], function(main) {
  return main;
});