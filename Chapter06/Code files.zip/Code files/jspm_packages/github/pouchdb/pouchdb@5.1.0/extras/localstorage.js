'use strict';

module.exports = require('../lib/plugins/localstorage');