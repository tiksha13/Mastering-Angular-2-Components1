import NextTickScheduler from './NextTickScheduler';

export default new NextTickScheduler();