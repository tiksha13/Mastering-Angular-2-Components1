export default class SubscriptionLog {
  constructor(public subscribedFrame: number,
              public unsubscribedFrame: number = Number.POSITIVE_INFINITY) {
  }
}