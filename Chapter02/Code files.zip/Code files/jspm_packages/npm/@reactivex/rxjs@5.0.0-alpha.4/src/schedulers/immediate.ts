import ImmediateScheduler from './ImmediateScheduler';

export default new ImmediateScheduler();