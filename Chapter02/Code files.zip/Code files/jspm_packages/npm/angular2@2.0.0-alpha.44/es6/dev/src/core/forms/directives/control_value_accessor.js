/* */ 
"format cjs";
import { CONST_EXPR } from 'angular2/src/core/facade/lang';
import { OpaqueToken } from 'angular2/src/core/di';
export const NG_VALUE_ACCESSOR = CONST_EXPR(new OpaqueToken("NgValueAccessor"));
//# sourceMappingURL=control_value_accessor.js.map