/* */ 
"format cjs";
export class XHR {
    get(url) { return null; }
}
//# sourceMappingURL=xhr.js.map