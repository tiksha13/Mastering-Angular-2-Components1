/* */ 
"format cjs";
// Public API for Services
export { AppRootUrl } from 'angular2/src/core/compiler/app_root_url';
export { UrlResolver } from 'angular2/src/core/compiler/url_resolver';
export { Title } from 'angular2/src/core/services/title';
//# sourceMappingURL=services.js.map