/* */ 
"format cjs";
//# sourceMappingURL=type_info.js.map