/* */ 
"format cjs";
export { wtfCreateScope, wtfLeave, wtfStartTimeRange, wtfEndTimeRange } from './src/core/profile/profile';
//# sourceMappingURL=profile.js.map