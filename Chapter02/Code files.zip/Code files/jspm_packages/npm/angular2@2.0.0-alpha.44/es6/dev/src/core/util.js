/* */ 
"format cjs";
// Public API for util
export { Class } from './util/decorators';
//# sourceMappingURL=util.js.map