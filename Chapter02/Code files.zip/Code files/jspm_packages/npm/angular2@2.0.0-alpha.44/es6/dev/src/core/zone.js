/* */ 
"format cjs";
// Public API for Zone
export { NgZone } from './zone/ng_zone';
//# sourceMappingURL=zone.js.map