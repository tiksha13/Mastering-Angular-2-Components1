/* */ 
'use strict';
var bootstrap_1 = require('./src/core/bootstrap');
exports.bootstrap = bootstrap_1.bootstrap;
