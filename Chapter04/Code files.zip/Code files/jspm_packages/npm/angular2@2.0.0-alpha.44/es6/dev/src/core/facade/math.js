/* */ 
"format cjs";
import { global } from 'angular2/src/core/facade/lang';
export var Math = global.Math;
export var NaN = typeof NaN;
//# sourceMappingURL=math.js.map