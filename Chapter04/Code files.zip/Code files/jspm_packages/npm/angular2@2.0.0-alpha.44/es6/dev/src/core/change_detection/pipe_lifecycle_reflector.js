/* */ 
"format cjs";
export function implementsOnDestroy(pipe) {
    return pipe.constructor.prototype.onDestroy;
}
//# sourceMappingURL=pipe_lifecycle_reflector.js.map