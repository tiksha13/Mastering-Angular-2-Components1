/* */ 
"format cjs";
export function isObservable(value) {
    return false;
}
//# sourceMappingURL=observable_facade.js.map