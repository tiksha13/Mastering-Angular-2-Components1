/* */ 
"format cjs";
// Public API for render
export { Renderer, RenderViewRef, RenderProtoViewRef, RenderFragmentRef, RenderViewWithFragments, DOCUMENT } from './render/render';
//# sourceMappingURL=render.js.map