/* */ 
"format cjs";
// Public API for LifeCycle
export { LifeCycle } from './life_cycle/life_cycle';
//# sourceMappingURL=lifecycle.js.map