/* */ 
"format cjs";
import { Reflector } from './reflector';
export { Reflector, ReflectionInfo } from './reflector';
import { ReflectionCapabilities } from './reflection_capabilities';
export var reflector = new Reflector(new ReflectionCapabilities());
//# sourceMappingURL=reflection.js.map