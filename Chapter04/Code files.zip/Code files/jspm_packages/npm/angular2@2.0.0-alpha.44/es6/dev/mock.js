/* */ 
"format cjs";
export * from './src/mock/mock_location_strategy';
export { LocationStrategy } from './src/router/location_strategy';
export { MockViewResolver } from 'angular2/src/mock/view_resolver_mock';
export { MockXHR } from 'angular2/src/core/compiler/xhr_mock';
//# sourceMappingURL=mock.js.map