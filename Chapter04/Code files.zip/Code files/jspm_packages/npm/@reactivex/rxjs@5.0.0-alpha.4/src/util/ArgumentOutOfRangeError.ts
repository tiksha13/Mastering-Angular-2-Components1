export default class ArgumentOutOfRangeError implements Error {
  name = 'ArgumentOutOfRangeError';
  message = 'argument out of range';
}