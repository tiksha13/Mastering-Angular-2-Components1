/* */ 
'use strict';
var browser_1 = require('./platform/browser');
exports.bootstrap = browser_1.bootstrap;
var angular_entrypoint_1 = require('./src/core/angular_entrypoint');
exports.AngularEntrypoint = angular_entrypoint_1.AngularEntrypoint;
