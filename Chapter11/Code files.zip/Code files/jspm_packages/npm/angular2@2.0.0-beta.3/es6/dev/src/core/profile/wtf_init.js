/* */ 
"format cjs";
/**
 * This is here because DART requires it. It is noop in JS.
 */
export function wtfInit() { }
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid3RmX2luaXQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhbmd1bGFyMi9zcmMvY29yZS9wcm9maWxlL3d0Zl9pbml0LnRzIl0sIm5hbWVzIjpbInd0ZkluaXQiXSwibWFwcGluZ3MiOiJBQUFBOztHQUVHO0FBQ0gsNEJBQTJCQSxDQUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogVGhpcyBpcyBoZXJlIGJlY2F1c2UgREFSVCByZXF1aXJlcyBpdC4gSXQgaXMgbm9vcCBpbiBKUy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHd0ZkluaXQoKSB7fVxuIl19