define(["github:pouchdb/pouchdb@5.1.0/dist/pouchdb.js"], function(main) {
  return main;
});