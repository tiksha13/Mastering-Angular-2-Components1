/* */ 
"format cjs";
export class SelectedPipe {
    constructor(pipe, pure) {
        this.pipe = pipe;
        this.pure = pure;
    }
}
//# sourceMappingURL=pipes.js.map