/* */ 
"format cjs";
export class ElementSchemaRegistry {
    hasProperty(tagName, propName) { return true; }
    getMappedPropName(propName) { return propName; }
}
//# sourceMappingURL=element_schema_registry.js.map