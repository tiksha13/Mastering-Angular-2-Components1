/* */ 
"format cjs";
//# sourceMappingURL=pipe_transform.js.map