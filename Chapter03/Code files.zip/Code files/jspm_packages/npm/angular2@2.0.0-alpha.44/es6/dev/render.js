/* */ 
"format cjs";
/**
 * This file is only used for dart applications and for internal examples
 * that compile with both JavaScript and Dart.
 *
 * JavaScript users should import from angular2/core.
 */
export * from './src/core/render';
//# sourceMappingURL=render.js.map