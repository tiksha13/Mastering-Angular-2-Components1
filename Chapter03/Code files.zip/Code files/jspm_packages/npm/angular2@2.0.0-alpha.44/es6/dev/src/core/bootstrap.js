/* */ 
"format cjs";
// Note: This file only exists so that Dart users can import
// bootstrap from angular2/bootstrap. JS users should import
// from angular2/core.
export { bootstrap } from './application';
//# sourceMappingURL=bootstrap.js.map