/* */ 
"format cjs";
//# sourceMappingURL=platform_reflection_capabilities.js.map