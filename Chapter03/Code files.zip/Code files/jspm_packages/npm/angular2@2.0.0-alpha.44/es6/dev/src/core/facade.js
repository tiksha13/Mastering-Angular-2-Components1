/* */ 
"format cjs";
// Public API for Facade
export { Type } from './facade/lang';
export { Observable, EventEmitter } from './facade/async';
export { WrappedException } from './facade/exceptions';
//# sourceMappingURL=facade.js.map