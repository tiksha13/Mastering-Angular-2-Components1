/* */ 
"format cjs";
export class EventBinding {
    constructor(eventName, elIndex, dirIndex, records) {
        this.eventName = eventName;
        this.elIndex = elIndex;
        this.dirIndex = dirIndex;
        this.records = records;
    }
}
//# sourceMappingURL=event_binding.js.map