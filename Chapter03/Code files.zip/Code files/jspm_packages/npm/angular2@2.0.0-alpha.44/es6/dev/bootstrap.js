/* */ 
"format cjs";
/**
 * This file is only used for dart applications and for internal examples
 * that compile with both JavaScript and Dart.
 */
export { bootstrap } from 'angular2/src/core/bootstrap';
//# sourceMappingURL=bootstrap.js.map