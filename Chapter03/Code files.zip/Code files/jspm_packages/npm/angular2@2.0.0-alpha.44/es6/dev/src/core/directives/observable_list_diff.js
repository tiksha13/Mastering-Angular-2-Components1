/* */ 
"format cjs";
// TS does not have Observables
export var workaround_empty_observable_list_diff;
//# sourceMappingURL=observable_list_diff.js.map