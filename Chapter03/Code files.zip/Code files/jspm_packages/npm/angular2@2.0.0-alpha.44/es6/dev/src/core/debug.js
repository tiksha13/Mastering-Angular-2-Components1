/* */ 
"format cjs";
export { DebugElement, asNativeElements, By, Scope, inspectElement } from './debug/debug_element';
export { inspectNativeElement, ELEMENT_PROBE_PROVIDERS, ELEMENT_PROBE_BINDINGS } from './debug/debug_element_view_listener';
//# sourceMappingURL=debug.js.map