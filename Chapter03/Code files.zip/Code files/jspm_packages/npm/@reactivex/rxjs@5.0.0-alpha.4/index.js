/* */ 
module.exports = require('./dist/cjs/Rx.KitchenSink');
