import Notification from '../Notification';

interface TestMessage {
  frame: number;
  notification: Notification<any>;
}

export default TestMessage;
