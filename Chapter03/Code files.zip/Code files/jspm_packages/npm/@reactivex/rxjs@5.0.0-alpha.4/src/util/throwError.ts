export default function throwError(e) { throw e; }
