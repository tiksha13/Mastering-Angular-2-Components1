export default class EmptyError implements Error {
  name = 'EmptyError';
  message = 'no elements in sequence';
}